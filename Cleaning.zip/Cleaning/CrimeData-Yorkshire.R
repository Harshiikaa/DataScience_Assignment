
# combination of yorkshire data of eaast , west , norht and south
new_data <- read.csv("crimeDataEastYorkshire.csv")
new_data0 <- read.csv("crimeDataWestYorkshire.csv")
new_data1 <- read.csv("crimeDataNorthYorkshire.csv")
new_data2 <- read.csv("crimeDataSouthYorkshire.csv")



# Concatenate the new dataset with the previously combined dataset
crimeDataYorkshire <- rbind(new_data ,new_data0 , new_data1, new_data2)

# Write the final combined data to a new CSV file
write.csv(crimeDataYorkshire, "crimeDataYorkshire.csv", row.names = FALSE)
View(crimeDataYorkshire)
