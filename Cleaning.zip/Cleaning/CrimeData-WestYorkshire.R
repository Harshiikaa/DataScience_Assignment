library(tidyverse)

#  Crime dataSets of West Yorkshire 2021 CSV files 
data1 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-01-thames-valley-street.csv")
data2 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-02-thames-valley-street.csv")
data3 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-03-thames-valley-street.csv")
data4 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-04-thames-valley-street.csv")
data5 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-05-thames-valley-street.csv")
data6 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-06-thames-valley-street.csv")
data7 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-07-thames-valley-street.csv")
data8 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-08-thames-valley-street.csv")
data9 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-09-thames-valley-street.csv")
data10 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-10-thames-valley-street.csv")
data11 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-11-thames-valley-street.csv")
data12 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2021-12-thames-valley-street.csv")


# Concatenate the data frames vertically
crimeDataWestYorkshire2021 <- rbind(data1, data2, data3,data4,data5,data6,data7,data8,data9,data10,data11,data12)

# Write the combined data to a new CSV file
write.csv(crimeDataWestYorkshire2021, "D:/RFiles/assignmentTry/Cleaned/crimeDataWestYorkshire2021.csv", row.names = FALSE)
View(crimeDataWestYorkshire2021)

#  Crime dataSets of West Yorkshire 2022 CSV files 

data13 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-01-thames-valley-street.csv")
data14 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-02-thames-valley-street.csv")
data15 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-03-thames-valley-street.csv")
data16 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-04-thames-valley-street.csv")
data17 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-05-thames-valley-street.csv")
data18 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-06-thames-valley-street.csv")
data19 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-07-thames-valley-street.csv")
data20 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-08-thames-valley-street.csv")
data21 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-09-thames-valley-street.csv")
data22 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-10-thames-valley-street.csv")
data23 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-11-thames-valley-street.csv")
data24 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2022-12-thames-valley-street.csv")


# Concatenate the data frames vertically
crimeDataWestYorkshire2022 <- rbind(data13, data14, data15,data16,data17,data18,data19,data20,data21,data22,data23,data24)

# Write the combined data to a new CSV file
write.csv(crimeDataWestYorkshire2022, "D:/RFiles/assignmentTry/Cleaned/crimeDataWestYorkshire2022.csv", row.names = FALSE)
View(crimeDataWestYorkshire2022)



#  Crime dataSets of West Yorkshire 2023 CSV files 
data25 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2023-01-thames-valley-street.csv")
data26 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2023-02-thames-valley-street.csv")
data27 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2023-03-thames-valley-street.csv")
data28 <- read.csv("D:/Data Science Assignment/West Yorkshire police/2023-04-thames-valley-street.csv")

# Concatenate the data frames vertically
crimeDataWestYorkshire2023 <- rbind(data25,data26,data27,data28)

# Write the combined data to a new CSV file
write.csv(crimeDataWestYorkshire2023, "crimeDataWestYorkshire2023.csv", row.names = FALSE)
View(crimeDataWestYorkshire2023)


# combination of yorkshire data of year 2021, 2022, 2023
new_data <- read.csv("crimeDataWestYorkshire2021.csv")
new_data0 <- read.csv("crimeDataWestYorkshire2022.csv")
new_data1 <- read.csv("crimeDataWestYorkshire2023.csv")


# Concatenate the new dataset with the previously combined dataset
crimeDataWestYorkshire <- rbind(new_data ,new_data0 , new_data1)

# Write the final combined data to a new CSV file
write.csv(crimeDataWestYorkshire, "crimeDataWestYorkshire.csv", row.names = FALSE)
View(crimeDataWestYorkshire)
