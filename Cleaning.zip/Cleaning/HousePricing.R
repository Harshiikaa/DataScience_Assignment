
library(tidyverse)

# house dataSets in CSV files 
housepricing2019 <- read.csv("D:/Data Science Assignment/housepricing2019.csv")
View(housepricing2019)
removed =select(housepricing2019,"X.8CAC1318.5AA6.0253.E053.6B04A8C08E51.","X165000","X5.24.2019.0.00", "M32.0JL","STANWAY.STREET","MANCHESTER","TRAFFORD","GREATER.MANCHESTER")
View(removed)
# Renamed multiple columns
pattern = ' .*$' 
housepricing2019<- removed %>% 
  rename( "code" = "X.8CAC1318.5AA6.0253.E053.6B04A8C08E51." ,
          "price" = "X165000",
          "postcode" =  "M32.0JL",
          "date" = "X5.24.2019.0.00",
          "address" = "STANWAY.STREET",
          "city/town" = "MANCHESTER",
          "District" = "TRAFFORD",
          "County" = "GREATER.MANCHESTER")
View(housepricing2019)
# Print the cleaned postcodes
print(clean_postcodes)

housepricing2019 <- housepricing2019 %>%
  mutate(Postcode = toupper(gsub(" ", "", postcode)))
View(housepricing2019)

# Write the combined data to a new CSV file
write.csv(housepricing2019, "D:/RFiles/assignmentTry/Cleaned/housepricing2019.csv", row.names = FALSE)
View(housepricing2019)

housepricing2019 = read_csv("D:/RFiles/assignmentTry/Cleaned/housepricing2019.csv")
View(housepricing2019)

# BOX PLOT OF AVERAGE HOUSE PRICES ACCROSS THE DISTRICTS IN 2022
# selecting yorkshire 
yorkshirehousepricing2019 <- housepricing2019 %>%
  filter(County ==  "WEST YORKSHIRE"  |County == "NORTH YORKSHIRE" | County == "YORK" | County == "SOUTH YORKSHIRE") 
View(yorkshirehousepricing2019)
write.csv(yorkshirehousepricing2019, "D:/RFiles/assignmentTry/Cleaned/yorkshirehousepricing2019.csv", row.names = FALSE)
View(yorkshirehousepricing2019)

# selecting oxfordshire 
oxfordshireHousepricing2019 <- housepricing2019 %>%
  filter(County == "OXFORDSHIRE") 
View(oxfordshireHousepricing2019)
write.csv(oxfordshireHousepricing2019, "D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2019.csv", row.names = FALSE)
View(oxfordshireHousepricing2019)

yorkshireHousepricing2019 <- read.csv("D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2019.csv")
View(yorkshireHousepricing2019)
oxfordshireHousepricing2019 <- read.csv("D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2019.csv")
View(oxfordshireHousepricing2019)

# C0MBINED BOTH COUNTIES
HousePricingOfBoth_2019 <-rbind(yorkshireHousepricing2019,oxfordshireHousepricing2019)
View(HousePricingOfBoth_2019)
write.csv(HousePricingOfBoth_2019, "D:/RFiles/assignmentTry/Cleaned/HousePricingOfBoth_2019.csv", row.names = FALSE)


# AVERAGE HOUSE PRICE

average_House_prices_2019 <- HousePricingOfBoth_2019 %>%
  group_by(County, District, Postcode, price) %>%            # Group by 'County' and 'District' columns
View(average_House_prices_2019)
write.csv(average_House_prices_2019, "D:/RFiles/assignmentTry/Cleaned/average_House_prices.csv", row.names = FALSE)
View(average_House_prices_2019)

average_House_prices_2019 = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices.csv")



#--------------------------------------------------------- housepricing2020 ----------------------------------------------------------------------------------

housepricing2020 <- read.csv("D:/Data Science Assignment/housepricing2020.csv")
View(housepricing2020)

housepricing2020 <- read.csv("D:/Data Science Assignment/housepricing2020.csv")
#View(housepricing2022)
removed =select(housepricing2020,"X.9FF0D96A.435D.11ED.E053.6C04A8C06383.","X36000", "ALBERT.STREET","CF43.4NW","X1.31.2020.0.00","FERNDALE",  "RHONDDA.CYNON.TAFF", "RHONDDA.CYNON.TAFF.1")
View(removed)
# Renamed multiple columns
housepricing2020<- removed %>% 
  rename( "code" = "X.9FF0D96A.435D.11ED.E053.6C04A8C06383." ,
          "price" = "X36000",
          "postcode" =  "CF43.4NW",
          "date" = "X1.31.2020.0.00",
          "address" = "ALBERT.STREET",
          "city/town" = "FERNDALE",
          "District" = "RHONDDA.CYNON.TAFF",
          "County" = "RHONDDA.CYNON.TAFF.1")
View(housepricing2020)


housepricing2020 <- housepricing2020 %>%
  mutate(Postcode = toupper(gsub(" ", "", postcode)))
View(housepricing2020)

# Write the combined data to a new CSV file
write.csv(housepricing2020, "D:/RFiles/assignmentTry/Cleaned/housepricing2020.csv", row.names = FALSE)
View(housepricing2020)


# BOX PLOT OF AVERAGE HOUSE PRICES ACCROSS THE DISTRICTS IN 2022
# selecting yorkshire 
yorkshireHousepricing2020 <- housepricing2020 %>%
  filter(County ==  "WEST YORKSHIRE"  |County == "NORTH YORKSHIRE" | County == "YORK" | County == "SOUTH YORKSHIRE") 
View(yorkshireHousepricing2020)
write.csv(yorkshireHousepricing2020, "D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2020.csv", row.names = FALSE)
View(yorkshireHousepricing2020)

# selecting oxfordshire 
oxfordshireHousepricing2020 <- housepricing2020 %>%
  filter(County == "OXFORDSHIRE") 
View(oxfordshireHousepricing2020)
write.csv(oxfordshireHousepricing2020, "D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2020.csv", row.names = FALSE)
View(oxfordshireHousepricing2020)

yorkshireHousepricing2020 <- read.csv("D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2020.csv")
View(yorkshireHousepricing2020)
oxfordshireHousepricing2020 <- read.csv("D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2020.csv")
View(oxfordshireHousepricing2020)

# C0MBINED BOTH COUNTIES
HousePricingOfBoth_2020 <-rbind(yorkshireHousepricing2020,oxfordshireHousepricing2020)
View(HousePricingOfBoth_2020)


# AVERAGE HOUSE PRICE

average_House_prices_2020 <- HousePricingOfBoth_2020 %>%
  group_by(County, District,Postcode) %>%            # Group by 'County' and 'District' columns
  summarise(Average_House_Price = mean(price))  # Calculate the mean price for each group
View(average_House_prices_2020)
write.csv(average_House_prices_2020, "D:/RFiles/assignmentTry/Cleaned/average_House_prices_2020.csv", row.names = FALSE)
View(average_House_prices_2020)

# ----------------------------------------------------- housepricing2021 ------------------------------------------------------------------------------------------

housepricing2021 <- read.csv("D:/Data Science Assignment/housepricing2021.csv")
View(housepricing2021)

housepricing2021 <- read.csv("D:/Data Science Assignment/housepricing2021.csv")
#View(housepricing2021)
removed =select(housepricing2021, "X.C6209F5F.03EF.295E.E053.6C04A8C0DDCC.","X245000", "SA2.7UX","X2021.05.24.00.00", "DUNVANT","SWANSEA","SWANSEA.1", "SWANSEA.2")
View(removed)
# Renamed multiple columns
housepricing2021<- removed %>% 
  rename( "code" = "X.C6209F5F.03EF.295E.E053.6C04A8C0DDCC." ,
          "price" = "X245000",
          "postcode" =  "SA2.7UX",
          "date" = "X2021.05.24.00.00",
          "address" = "DUNVANT",
          "city/town" = "SWANSEA",
          "District" = "SWANSEA.1",
          "County" = "SWANSEA.2")
View(housepricing2021)


housepricing2021 <- housepricing2021 %>%
  mutate(Postcode = toupper(gsub(" ", "", postcode)))
View(housepricing2021)

# Write the combined data to a new CSV file
write.csv(housepricing2021, "D:/RFiles/assignmentTry/Cleaned/housepricing2021.csv", row.names = FALSE)
View(housepricing2021)


# BOX PLOT OF AVERAGE HOUSE PRICES ACCROSS THE DISTRICTS IN 2022
# selecting yorkshire 
yorkshireHousepricing2021 <- housepricing2021 %>%
  filter(County ==  "WEST YORKSHIRE"  |County == "NORTH YORKSHIRE" | County == "YORK" | County == "SOUTH YORKSHIRE") 
View(yorkshireHousepricing2021)
write.csv(yorkshireHousepricing2021, "D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2021.csv", row.names = FALSE)
View(yorkshireHousepricing2021)

# selecting oxfordshire 
oxfordshireHousepricing2021 <- housepricing2021 %>%
  filter(County == "OXFORDSHIRE") 
View(oxfordshireHousepricing2021)
write.csv(oxfordshireHousepricing2021, "D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2021.csv", row.names = FALSE)
View(oxfordshireHousepricing2021)

yorkshireHousepricing2021 <- read.csv("D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2021.csv")
View(yorkshireHousepricing2021)
oxfordshireHousepricing2021 <- read.csv("D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2021.csv")
View(oxfordshireHousepricing2021)

# C0MBINED BOTH COUNTIES
HousePricingOfBoth_2021 <-rbind(yorkshireHousepricing2021,oxfordshireHousepricing2021)
View(HousePricingOfBoth_2021)


# AVERAGE HOUSE PRICE

average_House_prices_2021 <- HousePricingOfBoth_2021 %>%
  group_by(County, District,Postcode) %>%            # Group by 'County' and 'District' columns
  summarise(Average_House_Price = mean(price))  # Calculate the mean price for each group
View(average_House_prices_2021)
write.csv(average_House_prices_2021, "D:/RFiles/assignmentTry/Cleaned/average_House_prices_2021.csv", row.names = FALSE)
View(average_House_prices_2021)


###############################  HOUSE PRICING 2022 (boxplot) ########################################################

housepricing2022 <- read.csv("D:/Data Science Assignment/housepricing2022.csv")
View(housepricing2022)
removed =select(housepricing2022, "X.E53EDD2E.2473.83EC.E053.6B04A8C03A59.","X280000","B78.3XA","X2022.06.06.00.00","WESTMORLAND.CLOSE","TAMWORTH","TAMWORTH.1","STAFFORDSHIRE")
View(removed)
# Renamed multiple columns
housepricing2022<- removed %>% 
  rename( "code" = "X.E53EDD2E.2473.83EC.E053.6B04A8C03A59." ,
         "price" = "X280000",
         "postcode" =  "B78.3XA",
         "date" = "X2022.06.06.00.00",
         "address" = "WESTMORLAND.CLOSE",
         "city/town" = "TAMWORTH",
         "District" = "TAMWORTH.1",
         "County" = "STAFFORDSHIRE")
View(housepricing2022)



housepricing2022 <- housepricing2022 %>%
  mutate(Postcode = toupper(gsub(" ", "", postcode)))
View(housepricing2022)

# Write the combined data to a new CSV file
write.csv(housepricing2022, "D:/RFiles/assignmentTry/Cleaned/housepricing2022.csv", row.names = FALSE)
View(housepricing2022)


# BOX PLOT OF AVERAGE HOUSE PRICES ACCROSS THE DISTRICTS IN 2022
# selecting yorkshire 
yorkshireHousepricing2022 <- housepricing2022 %>%
  filter(County ==  "WEST YORKSHIRE"  |County == "NORTH YORKSHIRE" | County == "YORK" | County == "SOUTH YORKSHIRE") 
View(yorkshireHousepricing2022)
write.csv(yorkshireHousepricing2022, "D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2022.csv", row.names = FALSE)
View(yorkshireHousepricing2022)

# selecting oxfordshire 
oxfordshireHousepricing2022 <- housepricing2022 %>%
  filter(County == "OXFORDSHIRE") 
View(oxfordshireHousepricing2022)
write.csv(oxfordshireHousepricing2022, "D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2022.csv", row.names = FALSE)
View(oxfordshireHousepricing2022)

yorkshireHousepricing2022 <- read.csv("D:/RFiles/assignmentTry/Cleaned/yorkshireHousepricing2022.csv")
View(yorkshireHousepricing2022)
oxfordshireHousepricing2022 <- read.csv("D:/RFiles/assignmentTry/Cleaned/oxfordshireHousepricing2022.csv")
View(oxfordshireHousepricing2022)

# C0MBINED BOTH COUNTIES
HousePricingOfBoth_2022 <-rbind(yorkshireHousepricing2022,oxfordshireHousepricing2022)
View(HousePricingOfBoth_2022)


# AVERAGE HOUSE PRICE

average_House_prices_2022 <- HousePricingOfBoth_2022 %>%
  group_by(County, District, Postcode) %>%            # Group by 'County' and 'District' columns
  summarise(Average_House_Price = mean(price))  # Calculate the mean price for each group
View(average_House_prices_2022)
write.csv(average_House_prices_2022, "D:/RFiles/assignmentTry/Cleaned/average_House_prices_2022.csv", row.names = FALSE)
View(average_House_prices_2022)

#--------------------------END---------------------------------------------------------------------------------
average_House_prices_2019 = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices_2019.csv")
View(average_House_prices_2019)
average_House_prices_2020 = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices_2020.csv")
View(average_House_prices_2020)

average_House_prices_2021 = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices_2021.csv")
View(average_House_prices_2021)

average_House_prices_2022 = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices_2022.csv")
View(average_House_prices_2022)

houseprice_postcode_2019_2022_final = rbind(average_House_prices_2019,average_House_prices_2020,average_House_prices_2021,average_House_prices_2022)

View(houseprice_postcode_2019_2022_final)
write.csv(houseprice_postcode_2019_2022_final, "D:/RFiles/assignmentTry/Cleaned/houseprice_postcode_2019_2022_final.csv", row.names = FALSE)

houseprice_postcode_2019_2022_final = read_csv("D:/RFiles/assignmentTry/Cleaned/houseprice_postcode_2019_2022_final.csv")

#---------------------------Stacked group chart---------------------------------------------------------------
  
  # IT uses the same data set as above

# ------------------------------------END------------------------------------------------------------




# ------------------------------------- LINE GRAPH -------------------------------------------- 
housePricing2019_2022 <- rbind(average_House_prices_2019, average_House_prices_2020, average_House_prices_2021, average_House_prices_2022)

write.csv(housePricing2019_2022, "D:/RFiles/assignmentTry/Cleaned/housePricing2019_2022.csv", row.names = FALSE)
View(housePricing2019_2022)
