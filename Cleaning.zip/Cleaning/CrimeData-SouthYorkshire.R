library(tidyverse)

#  Crime dataSets of South Yorkshire 2021 CSV files 
data1 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2021-10-south-yorkshire-street.csv")
data2 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2021-11-south-yorkshire-street.csv")
data3 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2021-12-south-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataSouthYorkshire2021 <- rbind(data1, data2, data3)

# Write the combined data to a new CSV file
write.csv(crimeDataSouthYorkshire2021, "D:/RFiles/assignmentTry/Cleaned/crimeDataSouthYorkshire2021.csv", row.names = FALSE)
View(crimeDataSouthYorkshire2021)


#  Crime dataSets of South Yorkshire 2022 CSV files 
data4 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-01-south-yorkshire-street.csv")
data5 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-02-south-yorkshire-street.csv")
data6 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-03-south-yorkshire-street.csv")
data7 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-04-south-yorkshire-street.csv")
data8 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-05-south-yorkshire-street.csv")
data9 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-06-south-yorkshire-street.csv")
data10 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-07-south-yorkshire-street.csv")
data11 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-08-south-yorkshire-street.csv")
data12 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-09-south-yorkshire-street.csv")
data13 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-10-south-yorkshire-street.csv")
data14 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-11-south-yorkshire-street.csv")
data15 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2022-12-south-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataSouthYorkshire2022 <- rbind(data4, data5,data6,data7,data8,data9,data10,data11,data12,data13,data14,data15)

# Write the combined data to a new CSV file
write.csv(crimeDataSouthYorkshire2022, "D:/RFiles/assignmentTry/Cleaned/crimeDataSouthYorkshire2022.csv", row.names = FALSE)
View(crimeDataSouthYorkshire2022)


#  Crime dataSets of South Yorkshire 2023 CSV files 
data16 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2023-01-south-yorkshire-street.csv")
data17 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2023-02-south-yorkshire-street.csv")
data18 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2023-03-south-yorkshire-street.csv")
data19 <- read.csv("D:/Data Science Assignment/South Yorkshire police/2023-04-south-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataSouthYorkshire2023 <- rbind(data16,data17,data18,data19)

# Write the combined data to a new CSV file
write.csv(crimeDataSouthYorkshire2023, "crimeDataSouthYorkshire2023.csv", row.names = FALSE)
View(crimeDataSouthYorkshire2023)


# combination of yorkshire data of year 2021, 2022, 2023
new_data <- read.csv("crimeDataSouthYorkshire2021.csv")
new_data0 <- read.csv("crimeDataSouthYorkshire2022.csv")
new_data1 <- read.csv("crimeDataSouthYorkshire2023.csv")


# Concatenate the new dataset with the previously combined dataset
crimeDataSouthYorkshire <- rbind(new_data ,new_data0 , new_data1)

# Write the final combined data to a new CSV file
write.csv(crimeDataSouthYorkshire, "crimeDataSouthYorkshire.csv", row.names = FALSE)
View(crimeDataSouthYorkshire)

