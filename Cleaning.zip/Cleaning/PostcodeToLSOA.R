library(tidyverse)

PostcodeToLSOA <- read.csv("D:/Data Science Assignment/PostcodeToLSOA.csv")
View(PostcodeToLSOA)


distinct_ladnm <- unique(PostcodeToLSOA$ladnm)
print(distinct_ladnm)


select_items =select(PostcodeToLSOA, pcd7,lsoa11cd, ladnm)
View(select_items)

library(dplyr)

# Renamed multiple columns
PostcodeToLSOAClean<- select_items %>% 
  rename( "Postcode" = "pcd7" ,
          "LSOA.code" = "lsoa11cd",
          "Districts" = "ladnm")
View(PostcodeToLSOAClean)

PostcodeToLSOAClean <- PostcodeToLSOAClean %>%
  mutate(Postcode = gsub(" ", "", toupper(Postcode)))
View(PostcodeToLSOAClean)

write.csv(PostcodeToLSOAClean, "D:/RFiles/assignmentTry/Cleaned/PostcodeToLSOAClean.csv", row.names = FALSE)

PostcodeToLSOA_read = read_csv("D:/RFiles/assignmentTry/Cleaned/PostcodeToLSOAClean.csv")
View(PostcodeToLSOA_read)
