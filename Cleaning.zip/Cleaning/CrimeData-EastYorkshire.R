library(tidyverse)

#  Crime dataSets of East Yorkshire 2021 CSV files 
data1 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2021-10-humberside-street.csv")
data2 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2021-11-humberside-street.csv")
data3 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2021-12-humberside-street.csv")


# Concatenate the data frames vertically
crimeDataEastYorkshire2021 <- rbind(data1, data2, data3)

# Write the combined data to a new CSV file
write.csv(crimeDataEastYorkshire2021, "D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshire2021.csv", row.names = FALSE)
View(crimeDataEastYorkshire2021)


#  Crime dataSets of East Yorkshire 2022 CSV files 
data4 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-01-humberside-street.csv")
data5 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-02-humberside-street.csv")
data6 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-03-humberside-street.csv")
data7 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-04-humberside-street.csv")
data8 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-05-humberside-street.csv")
data9 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-06-humberside-street.csv")
data10 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-07-humberside-street.csv")
data11 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-08-humberside-street.csv")
data12 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-09-humberside-street.csv")
data13 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-10-humberside-street.csv")
data14 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-11-humberside-street.csv")
data15 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2022-12-humberside-street.csv")


# Concatenate the data frames vertically
crimeDataEastYorkshire2022 <- rbind(data4, data5,data6,data7,data8,data9,data10,data11,data12,data13,data14,data15)

# Write the combined data to a new CSV file
write.csv(crimeDataEastYorkshire2022, "D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshire2022.csv", row.names = FALSE)
View(crimeDataEastYorkshire2022)


#  Crime dataSets of East Yorkshire 2023 CSV files 
data16 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2023-01-humberside-street.csv")
data17 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2023-02-humberside-street.csv")
data18 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2023-03-humberside-street.csv")
data19 <- read.csv("D:/Data Science Assignment/East Yorkshirepolice/2023-04-humberside-street.csv")


# Concatenate the data frames vertically
crimeDataEastYorkshire2023 <- rbind(data16,data17,data18,data19)

# Write the combined data to a new CSV file
write.csv(crimeDataEastYorkshire2023, "crimeDataEastYorkshire2023.csv", row.names = FALSE)
View(crimeDataEastYorkshire2023)


# combination of yorkshire data of year 2021, 2022, 2023
new_data <- read.csv("crimeDataEastYorkshire2021.csv")
new_data0 <- read.csv("crimeDataEastYorkshire2022.csv")
new_data1 <- read.csv("crimeDataEastYorkshire2023.csv")


# Concatenate the new dataset with the previously combined dataset
crimeDataEastYorkshire <- rbind(new_data ,new_data0 , new_data1)

# Write the final combined data to a new CSV file
write.csv(crimeDataEastYorkshire, "crimeDataEastYorkshire.csv", row.names = FALSE)
View(crimeDataEastYorkshire)

crimeDataEastYorkshireCleaned = select(crimeDataEastYorkshire, -Longitude, -Latitude, -Context)
View(crimeDataEastYorkshireCleaned)

write.csv(crimeDataEastYorkshireCleaned, "D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshireCleaned.csv", row.names = FALSE)
View(crimeDataEastYorkshireCleaned)

#------------------------------------------ Cleaned data Imported Seperately ------------------------------------------------------------------------------------------------------

crimeDataEastYorkshireFinal = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshireCleaned.csv")
View(crimeDataEastYorkshireFinal)

#------------------------------------------ END ------------------------------------------------------------------------------------------------------
distinct_crime_types <- unique(crimeDataEastYorkshireFinal$Crime.type)
print(distinct_crime_types)

