library(tidyverse)

#  School dataSets  
School_2021 = read_csv("D:/Data Science Assignment/SchoolPerformance/2021-2022/england_ks4final.csv") %>% 
  mutate(Year = 2021) %>% 
  select( Year,PCODE,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()

School_2022 = read_csv("D:/Data Science Assignment/SchoolPerformance/2021-2022/england_ks4provisional.csv") %>% 
  mutate(Year = 2022) %>% 
  select( Year,PCODE,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()


SchoolData = rbind(School_2021,School_2022)
write.csv(SchoolData, "D:/RFiles/assignmentTry/Cleaned/SchoolData.csv",row.names = FALSE)


SchoolData <- SchoolData %>%
  mutate(Postcode = toupper(gsub(" ", "", PCODE))) %>% 
  select(-PCODE)
View(SchoolData)

write.csv(SchoolData, "D:/RFiles/assignmentTry/Cleaned/SchoolData.csv",row.names = FALSE)

CleanedSchoolData = SchoolData %>% 
  filter (ATT8SCR != "NE" & ATT8SCR != "SUPP") %>% 
  filter(ATT8SCR !=""& Postcode!="") %>% 
  select(Year,Postcode,SCHNAME, ATT8SCR,) %>% 
  na.omit() %>% 
  distinct()


colnames(CleanedSchoolData) = c( "Year", "Postcode", "SchoolName", "Attainment8Score")

write.csv(CleanedSchoolData, "D:/RFiles/assignmentTry/Cleaned/CleanedSchoolData.csv",row.names = FALSE)

CleanedSchoolData = read_csv("D:/RFiles/assignmentTry/Cleaned/CleanedSchoolData.csv")
View(CleanedSchoolData)
houseprice_postcode_2019_2022_final = read_csv("D:/RFiles/assignmentTry/Cleaned/houseprice_postcode_2019_2022_final.csv")
View(houseprice_postcode_2019_2022_final)

# School data cleaning seperatly for OXFORDSHIRE and YORKSHIRE


CleanedSchoolData$Postcode <- as.character(CleanedSchoolData$Postcode)
houseprice_postcode_2019_2022_final$Postcode <- as.character(houseprice_postcode_2019_2022_final$Postcode) 


CleanedSchoolData <- left_join(CleanedSchoolData, houseprice_postcode_2019_2022_final, by = "Postcode", relationship = "many-to-many") %>% 
  na.omit() %>% 
  distinct() 
View(CleanedSchoolData)
write.csv(CleanedSchoolData, "D:/RFiles/assignmentTry/Cleaned/CleanedSchoolData.csv",row.names = FALSE) 

OXFORDSHIRE_School <- CleanedSchoolData %>%
  filter(County == "OXFORDSHIRE") %>%
  na.omit() %>%
  distinct()
write.csv(OXFORDSHIRE_School, "D:/RFiles/assignmentTry/Cleaned/OXFORDSHIRE_School.csv",row.names = FALSE) 

distinct_counties <- unique(CleanedSchoolData$County)
print(distinct_counties)

YORKSHIRE_School <- CleanedSchoolData %>% 
  filter(County=="YORK" | County=="WEST YORKSHIRE" | County=="SOUTH YORKSHIRE" | County=="NORTH YORKSHIRE") %>% 
  na.omit() %>% 
  distinct()
View(YORKSHIRE_School)

write.csv(YORKSHIRE_School, "D:/RFiles/assignmentTry/Cleaned/YORKSHIRE_School.csv",row.names = FALSE) 

SchoolFinal = rbind(YORKSHIRE_School, OXFORDSHIRE_School)
write.csv(SchoolFinal, "D:/RFiles/assignmentTry/Cleaned/SchoolFinal.csv",row.names = FALSE) 
SchoolFinal = read_csv("D:/RFiles/assignmentTry/Cleaned/SchoolFinal.csv")
SchoolFinal$Attainment8Score <- as.numeric(SchoolFinal$Attainment8Score)

# Group by District and calculate the average Attainment8Score
averageAttainment_by_district <- SchoolFinal %>%
  group_by(County, District) %>%
  summarize(Average_Attainment8Score = mean(Attainment8Score, na.rm = TRUE))
write.csv(averageAttainment_by_district, "D:/RFiles/assignmentTry/Cleaned/averageAttainment_by_district.csv",row.names = FALSE) 

