library(tidyverse)

# Importing CSV file
PCPerformance <- read.csv("D:/Data Science Assignment/2018_fixed_pc_performance.csv")
View(PCPerformance)

# Declaring a variable by selecting specific columns
broadband_2018 <- select(PCPerformance, "postcode","Average.download.speed..Mbit.s.","Maximum.download.speed..Mbit.s.","Average.upload.speed..Mbit.s.","Minimum.upload.speed..Mbit.s.","Minimum.download.speed..Mbit.s.")

#Renamed the column name
broadband_2018<- broadband_2018 %>% 
  rename(  "AverageDownload" = "Average.download.speed..Mbit.s.",
           "MaxDownload" = "Maximum.download.speed..Mbit.s.",
           "AverageUpload" = "Average.upload.speed..Mbit.s.",
           "MaxUpload" = "Minimum.upload.speed..Mbit.s.",
           "Postcode" = "postcode",
           "MinDownload" = "Minimum.download.speed..Mbit.s.")
           
write.csv(broadband_2018,"D:/Data Science Assignment/broadband_2018.csv", row.names = FALSE)
broadband_2018 <- read.csv("D:/Data Science Assignment/broadband_2018.csv")
View(broadband_2018)

# columns_with_na <- colSums(is.na(broadband_2018)) > 0
# print(columns_with_na)

houseprice_postcode_2019_2022_final = read_csv("D:/RFiles/assignmentTry/Cleaned/houseprice_postcode_2019_2022_final.csv")
View(houseprice_postcode_2019_2022_final)

# Part 2: Data Joining, Renaming, Selection, and Filtering
Cleaned_Broadband_Speed = broadband_2018 %>% 
  left_join(houseprice_postcode_2019_2022_final, by = "Postcode") %>% 
  select(Postcode, AverageDownload, MaxDownload, MinDownload, AverageUpload, MaxUpload, District, County) %>% 
  na.omit()
View(Cleaned_Broadband_Speed)

Cleaned_Broadband_Speed = Cleaned_Broadband_Speed%>%
  filter(County ==  "WEST YORKSHIRE"  |County == "NORTH YORKSHIRE" | County == "YORK" | County == "SOUTH YORKSHIRE"| County == "OXFORDSHIRE") 
View(Cleaned_Broadband_Speed)
write.csv(Cleaned_Broadband_Speed, "D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed.csv", row.names = FALSE)
View(Cleaned_Broadband_Speed)

Cleaned_Broadband_Speed = read_csv("D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed.csv")
View(Cleaned_Broadband_Speed)

Cleaned_Broadband_Speed <- Cleaned_Broadband_Speed %>%
  distinct()

Cleaned_Broadband_Speed_2018 <- Cleaned_Broadband_Speed %>%
  group_by(County,District) %>%
  summarise(across(where(is.numeric), mean, na.rm = TRUE))

write.csv(Cleaned_Broadband_Speed, "D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed_2018.csv", row.names = FALSE)
Cleaned_Broadband_Speed_2018 = read_csv("D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed_2018.csv")

View(Cleaned_Broadband_Speed_2018)
################################## BOXPLOT ###################################################
# Load required libraries
library(tidyverse)

# Assuming you have already read and merged the data into the 'broadband' data frame
 broadbandCleaned =select(broadband,`Average.download.speed..Mbit.s..for.UFBB.lines`)

# 
# # Create the box plot using ggplot2
# ggplot(broadbandCleaned, aes(x = `Average.download.speed..Mbit.s..for.UFBB.lines`, y = District, fill = County)) +
#   geom_boxplot() +
#   xlab("Speed in Mbps") +
#   ylab("District Name") +
#   ggtitle("Box Plot of Average Download Speed by District and County") +
#   theme_minimal() +
#   theme(axis.text.y = element_text(hjust = 0.5))  # Adjust text alignment of y-axis labels
# 
