library(tidyverse)

#  Crime dataSets of North Yorkshire 2021 CSV files 
data1 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2021-10-north-yorkshire-street.csv")
data2 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2021-11-north-yorkshire-street.csv")
data3 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2021-12-north-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataNorthYorkshire2021 <- rbind(data1, data2, data3)

# Write the combined data to a new CSV file
write.csv(crimeDataNorthYorkshire2021, "D:/RFiles/assignmentTry/Cleaned/crimeDataNorthYorkshire2021.csv", row.names = FALSE)
View(crimeDataNorthYorkshire2021)


#  Crime dataSets of North Yorkshire 2022 CSV files 
data4 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-01-north-yorkshire-street.csv")
data5 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-02-north-yorkshire-street.csv")
data6 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-03-north-yorkshire-street.csv")
data7 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-04-north-yorkshire-street.csv")
data8 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-05-north-yorkshire-street.csv")
data9 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-06-north-yorkshire-street.csv")
data10 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-07-north-yorkshire-street.csv")
data11 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-08-north-yorkshire-street.csv")
data12 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-09-north-yorkshire-street.csv")
data13 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-10-north-yorkshire-street.csv")
data14 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-11-north-yorkshire-street.csv")
data15 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2022-12-north-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataNorthYorkshire2022 <- rbind(data4, data5,data6,data7,data8,data9,data10,data11,data12,data13,data14,data15)

# Write the combined data to a new CSV file
write.csv(crimeDataNorthYorkshire2022, "D:/RFiles/assignmentTry/Cleaned/crimeDataNorthYorkshire2022.csv", row.names = FALSE)
View(crimeDataNorthYorkshire2022)


#  Crime dataSets of North Yorkshire 2023 CSV files 
data16 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2023-01-north-yorkshire-street.csv")
data17 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2023-02-north-yorkshire-street.csv")
data18 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2023-03-north-yorkshire-street.csv")
data19 <- read.csv("D:/Data Science Assignment/North Yorkshire police/2023-04-north-yorkshire-street.csv")


# Concatenate the data frames vertically
crimeDataNorthYorkshire2023 <- rbind(data16,data17,data18,data19)

# Write the combined data to a new CSV file
write.csv(crimeDataNorthYorkshire2023, "crimeDataNorthYorkshire2023.csv", row.names = FALSE)
View(crimeDataNorthYorkshire2023)


# combination of yorkshire data of year 2021, 2022, 2023
new_data <- read.csv("crimeDataNorthYorkshire2021.csv")
new_data0 <- read.csv("crimeDataNorthYorkshire2022.csv")
new_data1 <- read.csv("crimeDataNorthYorkshire2023.csv")


# Concatenate the new dataset with the previously combined dataset
crimeDataNorthYorkshire <- rbind(new_data ,new_data0 , new_data1)

# Write the final combined data to a new CSV file
write.csv(crimeDataNorthYorkshire, "crimeDataNorthYorkshire.csv", row.names = FALSE)
View(crimeDataNorthYorkshire)

