#=============================================== LINEAR MODELING =============================================================================
Towns = read_csv("Cleaning/Cleaned datasets/Cleaned_Town_population.csv")%>%
  select(shortPostcode, Town, District, County)



crime=read_csv("Cleaning/cleaned datasets/Cleaned_Crime_Data.csv")

schools=read_csv("Cleaning\\Cleaned Datasets\\Cleaned_School_Data.csv") %>% 
  na.omit()

# ------------------------------ SCATTERPLOT OF HOUSE PRICE AND DOWNLOAD SPEED ---------------------------------------

#distinct_crime_types <- unique(crimeData2021_2022FinalClean$Crime.type)
#print(distinct_crime_types)
HousePricingOfBoth_2019 = read_csv("D:/RFiles/assignmentTry/Cleaned/HousePricingOfBoth_2019.csv")

Cleaned_Broadband_Speed_2018 = select(Cleaned_Broadband_Speed_2018,Postcode, AverageDownload, District, County )
View(Cleaned_Broadband_Speed_2018)
write.csv(Cleaned_Broadband_Speed_2018,"D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed_2018.csv",row.names = FALSE)
Cleaned_Broadband_Speed_2018 = read_csv("D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed_2018.csv") 



# Creating Dataset
HousePricing_AvgDwn = Cleaned_Broadband_Speed_2018 %>% 
  select(Postcode,AverageDownload) %>% 
  left_join(HousePricingOfBoth_2019,by="Postcode", relationship = "many-to-many") %>%
  na.omit() %>% 
  distinct()

HousePricing_AvgDwn$County[HousePricing_AvgDwn$County == "YORK" ] = "YORKSHIRE"
HousePricing_AvgDwn$County[HousePricing_AvgDwn$County == "WEST YORKSHIRE" ] = "YORKSHIRE"
HousePricing_AvgDwn$County[HousePricing_AvgDwn$County == "NORTH YORKSHIRE" ] = "YORKSHIRE"
HousePricing_AvgDwn$County[HousePricing_AvgDwn$County == "SOUTH YORKSHIRE" ] = "YORKSHIRE"
view(HousePricing_AvgDwn)

write.csv(HousePricing_AvgDwn,"D:/RFiles/assignmentTry/Cleaned/HousePricing_AvgDwn.csv",row.names = FALSE)


