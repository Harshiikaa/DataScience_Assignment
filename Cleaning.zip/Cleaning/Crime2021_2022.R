library(tidyverse)

#--------------------------- crime Data East Yorkshire 2021-2022-------------------------------

crimeDataEastYorkshire2021Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshire2021.csv")
crimeDataEastYorkshire2022Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataEastYorkshire2022.csv")
crimeDataEastYorkshire2021_2022 = rbind(crimeDataEastYorkshire2021Final,crimeDataEastYorkshire2022Final)
View(crimeDataEastYorkshire2021_2022)

#--------------------------- crime Data West Yorkshire 2021-2022-------------------------------

crimeDataWestYorkshire2021Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataWestYorkshire2021.csv")
crimeDataWestYorkshire2022Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataWestYorkshire2022.csv")
crimeDataWestYorkshire2021_2022 = rbind(crimeDataWestYorkshire2021Final,crimeDataWestYorkshire2022Final)
View(crimeDataWestYorkshire2021_2022)

#--------------------------- crime Data North Yorkshire 2021-2022-------------------------------

crimeDataNorthYorkshire2021Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataNorthYorkshire2021.csv")
crimeDataNorthYorkshire2022Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataNorthYorkshire2022.csv")
crimeDataNorthYorkshire2021_2022 = rbind(crimeDataNorthYorkshire2021Final,crimeDataNorthYorkshire2022Final)
View(crimeDataNorthYorkshire2021_2022)

#--------------------------- crime Data South Yorkshire 2021-2022-------------------------------

crimeDataSouthYorkshire2021Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataSouthYorkshire2021.csv")
crimeDataSouthYorkshire2022Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataSouthYorkshire2022.csv")
crimeDataSouthYorkshire2021_2022 = rbind(crimeDataSouthYorkshire2021Final,crimeDataSouthYorkshire2022Final)
View(crimeDataSouthYorkshire2021_2022)

#--------------------------- crime Data Oxfordshire 2021-2022-------------------------------

crimeDataOxfordshire2021Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataOxfordshire2021.csv")
crimeDataOxfordshire2022Final = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeDataOxfordshire2022.csv")
crimeDataOxfordshire2021_2022 = rbind(crimeDataOxfordshire2021Final,crimeDataOxfordshire2022Final)
view(crimeDataOxfordshire2021_2022)

#--------------------------- crime Data Yorkshire 2021-2022--------------------------------------------------------

crimeData_Yorkshire_2021_2022 = rbind(crimeDataEastYorkshire2021_2022,crimeDataWestYorkshire2021_2022,crimeDataNorthYorkshire2021_2022,crimeDataSouthYorkshire2021_2022)
write.csv(crimeData_Yorkshire_2021_2022, "D:/RFiles/assignmentTry/Cleaned/crimeData_Yorkshire_2021_2022.csv", row.names = FALSE)
View(crimeData_Yorkshire_2021_2022)

#--------------------------- crime Data 2021-2022--------------------------------------------------------

crimeData_2021_2022 = rbind(crimeData_Yorkshire_2021_2022,crimeDataOxfordshire2021_2022)
write.csv(crimeData_2021_2022, "D:/RFiles/assignmentTry/Cleaned/crimeData_2021_2022.csv", row.names = FALSE)
View(crimeData_2021_2022)

crimeData2021_2022Clean = select(crimeData2021_2022, -Longitude, -Latitude, -Context)  
  
  # Check which columns have NA values
  columns_with_na <- colSums(is.na(crimeData2021_2022Clean)) > 0
print(columns_with_na)
# Subset the dataset to exclude rows with NA values in specific columns
crimeData2021_2022CleanFinal <- crimeData2021_2022Clean[!is.na(crimeData2021_2022Clean$Crime.ID) & !is.na(crimeData2021_2022Clean$LSOA.code) & !is.na(crimeData2021_2022Clean$LSOA.name) & !is.na(crimeData2021_2022Clean$Last.outcome.category), ]
View(crimeData2021_2022CleanFinal)


columns_with_na <- colSums(is.na(crimeData2021_2022CleanFinal)) > 0
print(columns_with_na)
write.csv(crimeData2021_2022CleanFinal, "D:/RFiles/assignmentTry/Cleaned/crimeData2021_2022CleanFinal.csv", row.names = FALSE)

#------------------------------------------ FINAL --------------------------------------------------------

crimeData2021_2022FinalClean = read_csv("D:/RFiles/assignmentTry/Cleaned/crimeData2021_2022CleanFinal.csv")
View(crimeData2021_2022FinalClean)

#--------------------------------------------------------------------------------------------------
#----------------------------------------------DRUG OFFENCE Rate----------------------------------------------------

#distinct_crime_types <- unique(crimeData2021_2022FinalClean$Crime.type)
#print(distinct_crime_types)
DrugOffenseRate2021_2022 = filter(crimeData2021_2022FinalClean, Crime.type == "Drugs")
View(DrugOffenseRate2021_2022)
write.csv(DrugOffenseRate2021_2022, "D:/RFiles/assignmentTry/Cleaned/DrugOffenseRate2021_2022.csv", row.names = FALSE)

DrugOffenseRate2021_2022_Cleaned = read_csv("D:/RFiles/assignmentTry/Cleaned/DrugOffenseRate2021_2022.csv")
PostcodeToLSOA_read = read_csv("D:/RFiles/assignmentTry/Cleaned/PostcodeToLSOA.csv")

View(DrugOffenseRate2021_2022_Cleaned)

combined_Drug = left_join(DrugOffenseRate2021_2022_Cleaned, PostcodeToLSOA_read, by = "LSOA.code")  
View(combined_Drug)
write.csv(combined_Drug, "D:/RFiles/assignmentTry/Cleaned/combined_Drug.csv", row.names = FALSE)

combined_Drug = read_csv("D:/RFiles/assignmentTry/Cleaned/combined_Drug.csv")
View(combined_Drug)

# BOTH EAST AND WEST YORKSHIRE IS CONTROLLED BY HUMBERSIDE POLICE

district_drug_rates <- combined_Drug %>%
  group_by(Falls.within, Districts) %>%
  summarize(drug_offense_no = n()) %>%
  ungroup()
View(district_drug_rates)

# Calculate total districts number
total_districts <- nrow(district_drug_rates)
print(total_districts)


# Calculate total drug offenses
total_drug_offenses <- sum(district_drug_rates$drug_offense_no)
# Calculate  drug offenses rate
district_drug_rates <- district_drug_rates %>%
  mutate(drug_offense_rate = (drug_offense_no / total_drug_offenses) * 100)
print(district_drug_rates)

write.csv(district_drug_rates, "D:/RFiles/assignmentTry/Cleaned/district_drug_rates.csv", row.names = FALSE)
district_drug_rates= read_csv("D:/RFiles/assignmentTry/Cleaned/district_drug_rates.csv")
View(district_drug_rates)
# Selected 10 since there are 44 which causes clutter in visualization
selected_districts <- district_drug_rates %>%
  sample_n(10)
View(selected_districts)

write.csv(selected_districts, "D:/RFiles/assignmentTry/Cleaned/selected_districts.csv", row.names = FALSE)

#----------------------------------------------VEHICLE CRIME Rate----------------------------------------------------

Vehicle_Crime_Rate2021_2022 = filter(crimeData2021_2022FinalClean, Crime.type == "Vehicle crime") 
View(Vehicle_Crime_Rate2021_2022)

write.csv(Vehicle_Crime_Rate2021_2022, "D:/RFiles/assignmentTry/Cleaned/Vehicle_Crime_Rate2021_2022.csv", row.names = FALSE)



Vehicle_Crime_Rate2021_2022_Cleaned = read_csv("D:/RFiles/assignmentTry/Cleaned/Vehicle_Crime_Rate2021_2022.csv")
View(Vehicle_Crime_Rate2021_2022_Cleaned)

library(tidyr)
# Calculate crime rates


# Calculate the total count of vehicle crimes
total_count <- Vehicle_Crime_Rate2021_2022_Cleaned %>% 
  summarize(Count = n())

# Calculate the each count of vehicle crimes within Police areas
Falls_within_counts <- Vehicle_Crime_Rate2021_2022_Cleaned %>%
  group_by(Falls.within) %>%
  summarize(Count = n())
View(Falls_within_counts)

Vehicle_crime_data <- Falls_within_counts %>%
  filter(Falls.within == "Humberside Police" |Falls.within == "Thames Valley Police"| Falls.within == "North Yorkshire Police" | Falls.within == "South Yorkshire Police")
# Calculate the crime rate for Humberside Police
Vehicle_crime_data <- Vehicle_crime_data %>%
  mutate(Vehicle_Crime_Rate = (Count / total_count) * 100)

View(Vehicle_crime_data)

write.csv(Vehicle_crime_data, "D:/RFiles/assignmentTry/Cleaned/Vehicle_crime_data.csv", row.names = FALSE)



Vehicle_crime_data <- read_csv("D:/RFiles/assignmentTry/Cleaned/Vehicle_crime_data.csv")
View(Vehicle_crime_data)

crime_type_data <- Cleaned_Crime %>% 
  group_by(Crime.type, Year) %>% 
  summarize(total_crimes = sum(n)) %>% 
  spread(Crime.type,total_crimes) %>% 
  select(-c(Year))

radarchart(crime_type_data, 
           seg = 1, 
           cglcol = "black", 
           cglty = 1, 
           vlcex = 0.8, 
           title = "Crime Type Distribution",
           axistype = 2,
           axislabcol = "black",
           axislabcex = 0.8,
           axistext = colnames(crime_type_data),
           axistextcol = "black",
           axistextcex = 0.8)



# Filter the data for "Humberside Police"
humberside_data <- Falls_within_counts %>%
  filter(Falls.within == "Humberside Police")
# Calculate the crime rate for Humberside Police
humberside_data <- humberside_data %>%
  mutate(Crime.Rate = (Count / total_count) * 100)

# Filter the data for "North Yorkshire Police"
north_yorkshire_data <- Falls_within_counts %>%
  filter(Falls.within == "North Yorkshire Police")
# Calculate the crime rate for North Yorkshire Police
north_yorkshire_data <- north_yorkshire_data %>%
  mutate(Crime.Rate = (Count / total_count) * 100)
print(north_yorkshire_data)

# Filter the data for "South Yorkshire Police"
south_yorkshire_data <- Falls_within_counts %>%
  filter(Falls.within == "South Yorkshire Police")
# Calculate the crime rate for South Yorkshire Police
south_yorkshire_data <- south_yorkshire_data %>%
  mutate(Crime.Rate = (Count / total_count) * 100)
print(south_yorkshire_data)

# Filter the data for "South Yorkshire Police"
thames_valley_data <- Falls_within_counts %>%
  filter(Falls.within == "Thames Valley Police")
# Calculate the crime rate for South Yorkshire Police
thames_valley_data <- thames_valley_data %>%
  mutate(Crime.Rate = (Count / total_count) * 100)
print(thames_valley_data)



# Combine the results into a single dataset
combined_data_radar <- bind_rows(humberside_data, north_yorkshire_data, south_yorkshire_data, thames_valley_data)
# Print the combined dataset
View(combined_data_radar)




#----------------------------------------------Robbery Rate----------------------------------------------------

distinct_crime_types <- unique(crimeData2021_2022FinalClean$Crime.type)
print(distinct_crime_types)

RobberyRate2021_2022 = filter(crimeData2021_2022FinalClean, Crime.type == "Robbery")
View(RobberyRate2021_2022)
write.csv(RobberyRate2021_2022, "D:/RFiles/assignmentTry/Cleaned/RobberyRate2021_2022.csv", row.names = FALSE)


PostcodeToLSOA_read = read_csv("D:/RFiles/assignmentTry/Cleaned/PostcodeToLSOA.csv")
RobberyRate2021_2022 = read_csv("D:/RFiles/assignmentTry/Cleaned/RobberyRate2021_2022.csv")
View(RobberyRate2021_2022)

combined_robbery = left_join(RobberyRate2021_2022, PostcodeToLSOA_read, by = "LSOA.code")  
View(combined_robbery)
write.csv(combined_robbery, "D:/RFiles/assignmentTry/Cleaned/combined_robbery.csv", row.names = FALSE)

combined_robbery = read_csv("D:/RFiles/assignmentTry/Cleaned/combined_robbery.csv")
View(combined_robbery)

# BOTH EAST AND WEST YORKSHIRE IS CONTROLLED BY HUMBERSIDE POLICE


district_robbery_rates <- combined_robbery %>%
  group_by(Falls.within, Districts) %>%
  summarize(district_robbery_no = n()) %>%
  ungroup()
View(district_robbery_rates)


# Calculate total districts number
total_districts <- nrow(district_robbery_rates)
print(total_districts)


# Calculate total robbery offenses
total_robbery_offenses <- sum(district_robbery_rates$district_robbery_no)
# Calculate  robbery offenses rate
district_robbery_rates <- district_robbery_rates %>%
  mutate(robbery_rate = (district_robbery_no / total_robbery_offenses) * 100)
print(district_robbery_rates)

write.csv(district_robbery_rates, "D:/RFiles/assignmentTry/Cleaned/district_robbery_rates.csv", row.names = FALSE)


#-----------------DRUG OFFENCE Rate per 10k people of both Counties ----------------------------------------------------


crimeData = read_csv("D:/RFiles/assignmentTry/CleanedCrimeData.csv")

Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")



Drugs_2021_2022 <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(DrugOffenceRate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(Drugs_2021_2022, aes(x = Year, y = DrugOffenceRate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")


