library(tidyverse)
library(data.table)
library(dplyr)
library(scales)
library(purrr)
library(ggplot2)
# this library is for spider plot
install.packages("fmsb")
library(fmsb)

#------------------- BOX PLOT OF AVERAGE HOUSE PRICING 2022 -----------------------------------------------------------------------------------



average_House_prices_final = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices.csv")
view(average_House_prices_final)

ggplot(average_House_prices_final)+
  coord_flip() +
  geom_boxplot(aes(x= District,y= Average_House_Price,fill=District,stat = "identity")) + 
  scale_y_continuous(labels = scales::comma,limits = c(0,1000000)) +
  ggtitle("Average House Prices in Yorkshire&Oxfordshire - 2022")


#-----------------------------------------  END  -----------------------------------------------------------------------------------





#-------------  STACKED GROUPED BAR CHART AVERAGE HOUSE PRICING 2022 -----------------------------------------------------------------------------------

average_House_prices_final = read_csv("D:/RFiles/assignmentTry/Cleaned/average_House_prices.csv")
view(average_House_prices_final)
# Average House Prices in Yorkshire
average_prices_yorkshire <- c(
  '2019' = mean(data_yorkshire_19$Price),
  '2020' = mean(data_yorkshire_20$Price),
  '2021' = mean(data_yorkshire_21$Price),
  '2022' = mean(data_yorkshire_22$Price)
)

# Average House Prices in Oxfordshire
average_prices_oxfordshire <- c(
  '2019' = mean(data_oxfordshire_19$Price),
  '2020' = mean(data_oxfordshire_20$Price),
  '2021' = mean(data_oxfordshire_21$Price),
  '2022' = mean(data_oxfordshire_22$Price)
)

# Plotting the data
plot(average_prices_yorkshire, type='o', pch=19, col='blue', xlab='Year', ylab='Average House Price',
     main='Average House Price Trends (2019-2022)')
lines(average_prices_oxfordshire, type='o', pch=19, col='green')
legend('topright', legend=c('Yorkshire', 'Oxfordshire'), col=c('blue', 'green'), pch=19)
grid()

ggplot(average_House_prices_final,aes(x=District,y=Average_House_Price,fill=County)) +
  geom_bar(stat = "identity") + coord_flip() +
  scale_y_continuous(labels = scales::comma,limits = c(0,1000000)) +
  ggtitle("Average House Prices by District in 2022")



#-----------------------------------------END -----------------------------------------------------------------------------------












#============================================= BROADBAND SPEED ======================================================================================

#---------------- BOX PLOT OF BOARDBAND SPEED 2018  -----------------------------------------------------------------------------------
# Importing Cleaned Broadband CSV
Cleaned_Broadband_Speed_2018 = read_csv("D:/RFiles/assignmentTry/Cleaned/Cleaned_Broadband_Speed_2018.csv")


# Box Plot of average download speed (Box Plot)
ggplot(Cleaned_Broadband_Speed_2018, aes(x = District, y = AverageDownload, fill = County)) +
  geom_boxplot() + 
  coord_flip() +
  theme_minimal() + 
  ggtitle("Box Plot of Average Download Speed by District") +
  scale_fill_discrete(name = "County")
#-----------------------------------------END -----------------------------------------------------------------------------------




#---------------- BARCHART OF BOARDBAND SPEED 2018  -----------------------------------------------------------------------------------

# Bar Chart of Average and maximum download speeds (Bar Chart)
ggplot(Cleaned_Broadband_Speed_2018) +
  geom_bar(aes(x = AverageDownload , y = District, fill = County), stat = "identity") +
  theme_minimal() +
  ggtitle("Bar Chart of Average Download Speed by District")


#-----------------------------------------END -----------------------------------------------------------------------------------










#============================================= CRIME ======================================================================================

#--------------------------------- DRUG OFFENSE RATE (2021-2022) -----------------------------------------------

selected_districts= read_csv("D:/RFiles/assignmentTry/Cleaned/selected_districts.csv")
#


ggplot(selected_districts, aes(x = Districts, y = drug_offense_rate)) +
  geom_boxplot() + 
  coord_flip() +
  theme_minimal() + 
  ggtitle("Drug Offense Rate in Different Districts") 
#--------------------------------------------- END ----------------------------------------------------------------------




#--------------------------------- VEHICLE CRIME RATE (2021-2022) -----------------------------------------------
install.packages("fmsb")
library(fmsb)
# RadarChart of Vehicle Crime Rate
Vehicle_Crime_Rate2021_2022_Cleaned = read_csv("D:/RFiles/assignmentTry/Cleaned/Vehicle_Crime_Rate2021_2022.csv")


subset_data <- Vehicle_Crime_Rate2021_2022_Cleaned %>%
  filter(Crime.type == "Vehicle crime")
values <- subset_data %>%
  select(Crime.type, Falls.within, Location)  # Replace with the actual columns
radarchart(values, axistype = 1, 
           # Add other customization options as needed
           pfcol = "blue", plwd = 2, cglcol = "gray", cglty = 1, axislabcol = "black")

#--------------------------------- VEHICLE CRIME RATE (2021-2022) -----------------------------------------------



#---------------------------------  ROBBERY RATE (2021-2022) -----------------------------------------------


district_robbery_rates = read_csv("D:/RFiles/assignmentTry/Cleaned/district_robbery_rates.csv")

# Pie chart of robbery

ggplot(district_robbery_rates, aes(x = "", y = robbery_rate, fill = Districts)) +
  geom_bar( color = "white" , stat = "identity") +
  coord_polar(theta = "y") +
  theme_void() +
  labs(title = "Robbery in different District in 2021-2022")


#---------------------------------  DRUG OFFENSE RATE PER 10,000 PEOPLE -----------------------------------------------

selected_districts= read_csv("D:/RFiles/assignmentTry/Cleaned/selected_districts.csv")


crimeData = read_csv("D:/RFiles/assignmentTry/CleanedCrimeData.csv")

selected_districts <- crimeData %>%
  filter((County %in% c("OXFORDSHIRE", "YORKSHIRE")) & (Year %in% c(2021, 2022))) %>% 
  filter(CrimeType == "Drugs") %>% 
  mutate(drug_offense_rate = (CrimeCount / (Population2021+Population2022)) * 10000) %>% 
  as_tibble()

# Create a line chart
ggplot(selected_districts, aes(x = Year, y = drug_offense_rate, color = County)) +
  geom_line() +
  labs(x = "Year", y = "Drug Offense Rate per 10000 People", title = "Drug Offense Rate per 10000 People from 2021 to 2022", color = "County")
#------------------------------------------  END  ---------------------------------------------------------------------



#======================================== SCHOOL 2021-2022 =================================================================

 #------------------------ BOXPLOT of AVERAGE ATTAINMENT 8 SCORES 2022 -----------------------------------------------------------


OXFORDSHIRE_school = read_csv("D:/RFiles/assignmentTry/Cleaned/OXFORDSHIRE_school.csv")
YORKSHIRE_school = read_csv('D:/RFiles/assignmentTry/Cleaned/YORKSHIRE_School.csv')

averageAttainment_by_district = read_csv("D:/RFiles/assignmentTry/Cleaned/averageAttainment_by_district.csv")

# Create the boxplot
ggplot(averageAttainment_by_district, aes(x = County, y = Average_Attainment8Score, fill = County)) +
  geom_boxplot() +
  labs(title = "Average Attainment 8 Scores in Yorkshire and Oxfordshire",
       x = "County",
       y = "Average Attainment 8 Score") +
  scale_fill_brewer(palette = "Set3") +  # Use a colorful palette, e.g., Set3
  theme_minimal()

#-------------------------------------------------------------------------------------------------------------------------------------------

#   - line chart = yorkshire  district 

# merged_data_york <- YORKSHIREschool %>%
#   inner_join(Town, by ="shortPostcode")
# view(merged_data_york)

filtered_data_york <- YORKSHIRE_school %>%
  # filter(Year %in% c(2021, 2022)) %>%
  group_by(District, Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score))
filtered_data_york

ggplot(filtered_data_york, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "red") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "steelblue") +
  labs(title = "Yorkshire District Average Attainment Score from 2021 to 2022")



#   - line chart = oxfordshire district 

filtered_data_ox <- OXFORDSHIRE_school %>%
  # filter(Year %in% c(2021, 2022)) %>%
  group_by(District, Year) %>%
  summarise(AverageAttainment = mean(Attainment8Score))
filtered_data_ox

ggplot(filtered_data_ox, aes(x = Year, y = AverageAttainment, group = District)) +
  geom_line(size = 1, color = "red") +
  geom_text(aes(label = AverageAttainment), vjust = -0.85) +
  geom_point(size = 2, color = "steelblue") +
  labs(title = "Oxfordshire District Average Attainment Score from 2021 to 2022")


# ----------------------------------------- END -----------------------------------------------------------------------------









#=============================================== LINEAR MODELING =============================================================================

# ------------------------------ SCATTERPLOT OF HOUSE PRICE AND DOWNLOAD SPEED ---------------------------------------


HousePricing_AvgDwn = read_csv("D:/RFiles/assignmentTry/Cleaned/HousePricing_AvgDwn.csv") 

HousePricing_AvgDwn_clean <- na.omit(HousePricing_AvgDwn)
# Graph
ggplot(HousePricing_AvgDwn_clean, aes(x= AverageDownload, y = price))+
  geom_point(data = filter(HousePricing_AvgDwn_clean, County == "YORKSHIRE") , aes(color = "YORKSHIRE"))+
  geom_point(data = filter(HousePricing_AvgDwn_clean, County == "OXFORDSHIRE") , aes(color = "OXFORDSHIRE"))+
  geom_smooth(method = lm, se = FALSE, color= "black")+ 
  labs(x = "Average Download", y = "price",color = "County",  title = "Corelation of HousePrice and Average Download" )+ 
  scale_y_continuous(labels = label_comma(), limits = c(0,1500000))

# ------------------------------------------------------- END -------------------------------------------------------------





# ------------------------------ SCATTERPLOT OF HOUSE PRICE AND DRUG RATES --------------------------------------
HousePrices = prices %>%
  filter(Year=="2021" | Year=="2022" ) %>%
  left_join(District,by="shortPostcode") %>%  
  group_by(District,County) %>%
  summarise(Price=mean(Price))

Drugs = crime %>%
  left_join(District,by="shortPostcode") %>%
  group_by(District,County) %>%
  filter(CrimeType=="Drugs") %>% 
  na.omit()

lm_res1 = HousePrices %>% left_join(Drugs ,by="District") %>% 
  na.omit()
model1 = lm(data= lm_res1, Price~CrimeCount)
summary(model1)

color= c("OXFORDSHIRE" = "yellow", "YORKSHIRE" = "Green")

ggplot(lm_res1,aes(x=CrimeCount,y=Price)) +
  geom_point(data = filter(lm_res1,County.x=="YORKSHIRE"),aes(color="YORKSHIRE"))+
  geom_point(data = filter(lm_res1,County.x=="OXFORDSHIRE"), aes(color="OXFORDSHIRE")) +
  geom_smooth(method=lm,se=FALSE,color="peachpuff4")+
  labs(x="count",y="Price",title="House Prices vs Drug",color="County")
# ------------------------------------------------------- END -------------------------------------------------------------







# ------------------------------ SCATTERPLOT OF AVG ATTAINMENT 8 SCORES VS HOUSEPRICE  ---------------------------------------

HousePricingOfBoth_2019 = read_csv("D:/RFiles/assignmentTry/Cleaned/HousePricingOfBoth_2019.csv")
averageAttainment_by_district = read_csv("D:/RFiles/assignmentTry/Cleaned/averageAttainment_by_district.csv")


averageAttainment_by_districtFinal= averageAttainment_by_district %>%
  left_join(District,by="shortPostcode") %>%  
  group_by(District,County) %>%
  summarise(meanAttainment=mean(Attainment8Score))


HousePrices = HousePricingOfBoth_2019 %>%
  left_join(District,by="shortPostcode") %>%  
  group_by(District,County) %>%
  summarise(Price=mean(Price))

res2 = HousePrices %>% left_join(attainment ,by="District") %>% 
  na.omit()
res2
model1 = lm(data= res2, Price~meanAttainment)
summary(model1)

color= c("OXFORDSHIRE" = "yellow", "YORKSHIRE" = "green")

ggplot(lm_res2,aes(x=meanAttainment,y=Price)) +
  geom_point(data = filter(res2,County.x=="YORKSHIRE"),aes(color="YORKSHIRE"))+
  geom_point(data = filter(res2,County.x=="OXFORDSHIRE"), aes(color="OXFORDSHIRE")) +
  geom_smooth(method=lm,se=FALSE,color="peachpuff4")+
  labs(x="attainment",y="Price",title="average attainment  vs house prices",color="County")

# ------------------------------------------------------- END -------------------------------------------------------------


# ------------------------------ SCATTERPLOT OF AVERAGE DOWNLOAD SPEED VS DRUG OFFENSE ---------------------------------------

# Read Town populations data
District = read_csv("D:/RFiles/assignmentTry/Cleaned/HousePricingOfBoth_2019.csv")

# Calculate the average attainment score for each town and county
BroardbandSpeeds <- speeds %>%
  left_join(District, by = "shortPostcode") %>%
  group_by(District, County) %>%
  summarise(AverageDownload = mean(Avgdownload))


Drugs = crime %>%
  left_join(District,by="shortPostcode") %>%
  group_by(District,County) %>%
  filter(CrimeType=="Drugs") %>% 
  na.omit()

# Combine the spped and drug offence rate data
lm_res3 = Drugs %>% left_join(BroardbandSpeeds, by = "District") %>% 
  na.omit()

# Perform linear regression to predict drug offence rate based on mean attainment
model3 = lm(data = lm_res3, AverageDownload ~ CrimeCount)

# Display the summary of the linear regression model
summary(model3)
# Define color mapping
color_mapping = c("OXFORDSHIRE" = "black", "YORKSHIRE" = "yellow")
# Create a scatter plot with regression line
ggplot(lm_res3, aes(x = CrimeCount, y = AverageDownload, color = County.x)) +
  geom_point() +
  geom_smooth(method = lm, se = FALSE, color = "green") +
  scale_color_manual(values = color_mapping) +  # Apply color mapping
  labs(x = "Drug rate per 10000", y = "Download speed Mbps", title = "Average download speed vs Drug Offence Rate per 10000 People", color = "County") +
  theme_minimal()



# ------------------------------------------------------- END -------------------------------------------------------------





# ------------------------------ AVG ATTAINMENT 8 SCORES VS AVG DOWNLOAD SPEED ---------------------------------------

# Calculate mean attainment score per town and county
attainment <- schools %>%
  left_join(Towns, by = "shortPostcode") %>%  
  group_by(Town, County) %>%
  summarise(meanAttainment = mean(Attainment8Score))


# Calculate average download speed per town and county
download_speeds <- speeds %>%
  left_join(Towns_Populations, by = "shortPostcode") %>% 
  group_by(Town, County) %>%
  summarise(meanDownloadSpeed = mean(Avgdownload)) %>%
  na.omit()

# Merge the data frames and remove rows with missing values
lm_res5 <- attainment %>%
  left_join(download_speeds, by = "Town") %>% 
  na.omit()

model <- lm(meanDownloadSpeed ~ meanAttainment, data = lm_res5)

summary(model)

# Create a scatter plot
color <- c("OXFORDSHIRE" = "yellow", "YORKSHIRE" = "Green")

ggplot(lm_res5, aes(x = meanAttainment, y = meanDownloadSpeed)) +
  geom_point(data = filter(lm_res5, County.x == "YORKSHIRE"), aes(color = "YORKSHIRE")) +
  geom_point(data = filter(lm_res5, County.x == "OXFORDSHIRE"), aes(color = "OXFORDSHIRE")) +
  geom_smooth(method = lm, se = FALSE, color = "peachpuff4") +
  labs(x = "Average Attainment Score", y = "Average Download Speed", title = "Average Attainment Score vs Average Download Speed", color = "County")




# ------------------------------------------------------- END -------------------------------------------------------------